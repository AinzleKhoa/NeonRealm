package gameshop.service;

import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import gameshop.model.GoogleUser;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Collections;

public class GoogleOAuthService {
    private static final String CLIENT_ID = "809722736314-p12thbcom86al3s29ob4gulekvb283mr.apps.googleusercontent.com";
    private static final String CLIENT_SECRET = "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";
    private static final String REDIRECT_URI = "http://localhost:8080/NeonRealm/google-callback";
    private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();

    // Lấy access token từ Authorization Code
    public GoogleTokenResponse getTokens(String code) throws IOException {
    return new GoogleAuthorizationCodeTokenRequest(
            new NetHttpTransport(),
            JSON_FACTORY,
            "https://oauth2.googleapis.com/token",
            CLIENT_ID,
            CLIENT_SECRET,
            code,
            REDIRECT_URI)
            .execute();
}


    // Lấy thông tin user từ token
    public GoogleUser getUserInfo(String idTokenString) throws IOException, GeneralSecurityException {
    GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(
            new NetHttpTransport(), JSON_FACTORY)
            .setAudience(Collections.singletonList(CLIENT_ID))
            .build();
    
    GoogleIdToken idToken = verifier.verify(idTokenString);
    if (idToken == null) {
        throw new IllegalArgumentException("Invalid ID token.");
    }

    GoogleIdToken.Payload payload = idToken.getPayload();
    return new GoogleUser(
            payload.getEmail(),
            (String) payload.get("name"),
            (String) payload.get("picture")
    );
}

}

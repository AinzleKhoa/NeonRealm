/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gameshop.model;

import java.math.BigDecimal;
import java.time.LocalDateTime ;

/**
 *
 * @author Ainzle
 */
public class Order {

    private int orderId;
    private int userId;
    private BigDecimal totalPrice;
    private String discountCode;
    private LocalDateTime createdAt;

    public Order(int orderId, int userId, BigDecimal totalPrice, String discountCode, LocalDateTime  createdAt) {
        this.orderId = orderId;
        this.userId = userId;
        this.totalPrice = totalPrice;
        this.discountCode = discountCode;
        this.createdAt = createdAt;
    }

    public Order(int userId, BigDecimal totalPrice, String discountCode) {
        this.userId = userId;
        this.totalPrice = totalPrice;
        this.discountCode = discountCode;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getDiscountCode() {
        return discountCode;
    }

    public void setDiscountCode(String discountCode) {
        this.discountCode = discountCode;
    }

    public LocalDateTime  getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime  createdAt) {
        this.createdAt = createdAt;
    }

}
